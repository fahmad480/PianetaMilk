<div class="jumbotron jumbotron-fluid">
    <div class="container">
        <center>
            <h1 class="display-4"><?= $title; ?></h1>
            <p class="lead"><?= $pesan; ?></p>
        </center>
    </div>
</div>